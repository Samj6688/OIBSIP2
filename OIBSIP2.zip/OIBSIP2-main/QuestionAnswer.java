package com.example.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "Name the national bird of India?",
            "Which one is not the programming language?",
            "Where you are watching this video?",
            "Which company owns the Apple?"
    };

    public static String choices[][] = {
            {"Peacock","Crow","sparrow","parrots"},
            {"Java","Kotlin","Notepad","Python"},
            {"Facebook","Whatsapp","Instagram","Youtube"},
            {"Google","Apple","Nokia","Samsung"}
    };

    public static String correctAnswers[] = {
            "Peacock",
            "Notepad",
            "Youtube",
            "Apple"
    };

}
